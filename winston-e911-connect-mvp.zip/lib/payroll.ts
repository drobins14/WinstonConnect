export type PayrollInput = {
  employeeId: string;
  employeeName: string;
  workedHours: number;
  holiday: number;
  vacation: number;
  sick: number;
  adminTraining: number;
};

export type PayrollRow = PayrollInput & {
  regular: number;
  overtime: number;
  grandTotal: number;
};

export function calculatePayroll(row: PayrollInput): PayrollRow {
  const worked = Math.max(0, Number(row.workedHours || 0));
  const regular = Math.min(worked, 80);
  const overtime = Math.max(worked - 80, 0);
  const leave = Number(row.holiday || 0) + Number(row.vacation || 0) + Number(row.sick || 0) + Number(row.adminTraining || 0);

  return {
    ...row,
    regular,
    overtime,
    grandTotal: worked + leave,
  };
}
