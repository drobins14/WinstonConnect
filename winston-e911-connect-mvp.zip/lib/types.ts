export type Role = 'employee' | 'supervisor' | 'admin';

export type Profile = {
  id: string;
  username: string;
  first_name: string;
  last_name: string;
  role: Role;
  shift_group: string | null;
  status: 'active' | 'inactive';
  phone: string | null;
  email: string | null;
  must_reset_password: boolean;
  profile_complete: boolean;
};

export type TimeCardCategory =
  | 'regular'
  | 'overtime'
  | 'holiday'
  | 'holiday_worked'
  | 'vacation'
  | 'sick'
  | 'admin_training';
