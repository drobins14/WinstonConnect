import Link from 'next/link';
import { Bell, Shield } from 'lucide-react';

export function Header() {
  return (
    <header className="sticky top-0 z-10 border-b border-white/10 bg-navy/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link href="/dashboard" className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-full border border-gold bg-panel">
            <Shield className="text-gold" />
          </div>
          <div>
            <div className="font-bold leading-tight">Winston County E911 Connect</div>
            <div className="text-xs text-white/60">Scheduling • Communication • Payroll • Operations</div>
          </div>
        </Link>
        <div className="flex items-center gap-3">
          <Bell className="text-gold" />
          <Link className="btn-secondary py-2" href="/admin">Admin</Link>
        </div>
      </div>
    </header>
  );
}
