import Link from 'next/link';

const items = [
  ['Dashboard', '/dashboard'],
  ['Schedule', '/schedule'],
  ['Time Card', '/time-card'],
  ['Payroll', '/admin/payroll'],
  ['Users', '/admin/users'],
  ['Settings', '/settings'],
];

export function Nav() {
  return (
    <nav className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-4">
      {items.map(([label, href]) => (
        <Link key={href} href={href} className="rounded-full bg-white/10 px-4 py-2 text-sm hover:bg-white/15">
          {label}
        </Link>
      ))}
    </nav>
  );
}
