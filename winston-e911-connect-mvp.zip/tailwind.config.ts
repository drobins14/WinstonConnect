import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: '#081426',
        panel: '#111d2f',
        gold: '#d7a83d',
        red911: '#d64040',
        slate911: '#263449',
      },
    },
  },
  plugins: [],
};
export default config;
