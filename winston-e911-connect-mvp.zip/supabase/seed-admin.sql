-- Create admin auth user in Supabase Dashboard > Authentication > Add user:
-- Email: admin@winston-e911.local
-- Password: Admin@911
-- Then copy the created user UUID and replace USER_UUID below.

insert into public.profiles (
  id, username, first_name, last_name, role, shift_group, status, email,
  must_reset_password, profile_complete
) values (
  'USER_UUID',
  'admin',
  'System',
  'Administrator',
  'admin',
  'Setup',
  'active',
  'admin@winston-e911.local',
  true,
  true
);
