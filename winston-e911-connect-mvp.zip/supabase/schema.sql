create type public.app_role as enum ('employee', 'supervisor', 'admin');
create type public.user_status as enum ('active', 'inactive');
create type public.time_card_status as enum ('draft', 'submitted', 'approved', 'returned', 'locked');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  first_name text not null,
  last_name text not null,
  role app_role not null default 'employee',
  shift_group text,
  status user_status not null default 'active',
  phone text,
  email text,
  must_reset_password boolean not null default true,
  profile_complete boolean not null default false,
  notification_app boolean not null default true,
  notification_email boolean not null default true,
  notification_sms boolean not null default false,
  accent_color text not null default '#d7a83d',
  created_at timestamptz not null default now()
);

create table public.shift_types (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  start_time time,
  end_time time,
  default_color text not null,
  is_open_shift boolean not null default false
);

create table public.schedule_entries (
  id uuid primary key default gen_random_uuid(),
  entry_date date not null,
  profile_id uuid references public.profiles(id),
  shift_type_id uuid references public.shift_types(id),
  label text,
  notes text,
  trainee_hours numeric(6,2) default 0,
  created_at timestamptz not null default now()
);

create table public.pay_periods (
  id uuid primary key default gen_random_uuid(),
  start_date date not null,
  end_date date not null,
  is_locked boolean not null default false
);

create table public.time_cards (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id),
  pay_period_id uuid not null references public.pay_periods(id),
  status time_card_status not null default 'draft',
  submitted_at timestamptz,
  approved_at timestamptz,
  approved_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique(profile_id, pay_period_id)
);

create table public.time_card_lines (
  id uuid primary key default gen_random_uuid(),
  time_card_id uuid not null references public.time_cards(id) on delete cascade,
  work_date date not null,
  worked_hours numeric(6,2) not null default 0,
  holiday numeric(6,2) not null default 0,
  vacation numeric(6,2) not null default 0,
  sick numeric(6,2) not null default 0,
  admin_training numeric(6,2) not null default 0,
  notes text
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id),
  title text not null,
  body text not null,
  channel text not null default 'app',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.shift_types enable row level security;
alter table public.schedule_entries enable row level security;
alter table public.pay_periods enable row level security;
alter table public.time_cards enable row level security;
alter table public.time_card_lines enable row level security;
alter table public.notifications enable row level security;

create policy "profiles readable" on public.profiles for select using (auth.uid() is not null);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);
create policy "schedule readable" on public.schedule_entries for select using (auth.uid() is not null);
create policy "shift types readable" on public.shift_types for select using (auth.uid() is not null);
create policy "pay periods readable" on public.pay_periods for select using (auth.uid() is not null);
create policy "own time cards" on public.time_cards for all using (auth.uid() = profile_id);
create policy "own notifications" on public.notifications for select using (auth.uid() = profile_id);

insert into public.shift_types (code, name, start_time, end_time, default_color, is_open_shift) values
('DAY', 'Day Shift', '07:00', '19:00', '#3ddc84', false),
('NIGHT', 'Night Shift', '19:00', '07:00', '#7c5cff', false),
('OPEN_DAY', 'Open Day Shift', '07:00', '19:00', '#ffd43b', true),
('OPEN_NIGHT', 'Open Night Shift', '19:00', '07:00', '#22d3ee', true),
('VAC', 'Vacation', null, null, '#3b82f6', false),
('SICK', 'Sick Leave', null, null, '#ef4444', false),
('TRAIN', 'Training', null, null, '#a855f7', false);
