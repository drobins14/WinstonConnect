'use client';

import { useState } from 'react';
import { supabaseBrowser } from '@/lib/supabaseClient';

export default function LoginPage() {
  const supabase = supabaseBrowser();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('Admin@911');
  const [error, setError] = useState('');

  async function signIn() {
    setError('');
    const email = username.includes('@') ? username : `${username}@winston-e911.local`;
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
    else location.href = '/dashboard';
  }

  return (
    <main className="grid min-h-screen place-items-center px-4">
      <section className="card w-full max-w-md">
        <h1 className="text-2xl font-bold">Sign in</h1>
        <p className="mb-6 text-sm text-white/60">Use first initial + last name. Example: Drobins</p>
        <label className="text-sm">Username</label>
        <input className="input mb-4 mt-1" value={username} onChange={e => setUsername(e.target.value)} />
        <label className="text-sm">Password</label>
        <input className="input mb-4 mt-1" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        {error && <p className="mb-4 rounded-lg bg-red911/20 p-3 text-sm text-red-200">{error}</p>}
        <button className="btn w-full" onClick={signIn}>Sign In</button>
      </section>
    </main>
  );
}
