import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';

export default function Dashboard() {
  return (
    <>
      <Header /><Nav />
      <main className="mx-auto grid max-w-7xl gap-4 px-4 pb-10 md:grid-cols-3">
        <section className="card md:col-span-2">
          <h1 className="text-2xl font-bold">Operations Dashboard</h1>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            <div className="rounded-xl bg-green-500/15 p-4">Day Shift: Fully Staffed</div>
            <div className="rounded-xl bg-red911/20 p-4">Night Shift: 1 Open Position</div>
            <div className="rounded-xl bg-white/10 p-4">Pending Time Cards: 0</div>
            <div className="rounded-xl bg-white/10 p-4">Trainees Scheduled Today: 0</div>
          </div>
        </section>
        <section className="card">
          <h2 className="font-bold text-gold">Current Pay Period</h2>
          <p className="mt-3 text-3xl font-black">0 hrs</p>
          <p className="text-white/60">Time card not submitted</p>
        </section>
      </main>
    </>
  );
}
