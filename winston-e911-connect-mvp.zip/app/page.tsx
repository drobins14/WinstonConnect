import Link from 'next/link';

export default function Home() {
  return (
    <main className="grid min-h-screen place-items-center px-4">
      <section className="card w-full max-w-md text-center">
        <div className="mx-auto mb-5 grid h-28 w-28 place-items-center rounded-full border-2 border-gold bg-navy text-3xl font-black text-gold">
          911
        </div>
        <h1 className="text-3xl font-bold">Winston County E911 Connect</h1>
        <p className="mt-2 text-white/70">Communications Operations Management System</p>
        <p className="mt-1 text-sm text-gold">Scheduling • Communication • Payroll • Operations</p>
        <Link href="/login" className="btn mt-8 block">Sign In</Link>
      </section>
    </main>
  );
}
