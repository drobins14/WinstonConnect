import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Winston County E911 Connect',
  description: 'Scheduling • Communication • Payroll • Operations',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
