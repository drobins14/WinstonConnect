'use client';

import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';
import { calculatePayroll } from '@/lib/payroll';

export default function PayrollPage() {
  const rows = [
    calculatePayroll({ employeeId:'1', employeeName:'Daniel Robins', workedHours:147, holiday:0, vacation:0, sick:0, adminTraining:0 }),
    calculatePayroll({ employeeId:'2', employeeName:'Example Employee', workedHours:84, holiday:0, vacation:12, sick:0, adminTraining:0 }),
  ];
  return (
    <>
      <Header /><Nav />
      <main className="mx-auto max-w-7xl px-4 pb-10">
        <section className="card">
          <h1 className="text-2xl font-bold">Build Payroll</h1>
          <p className="mt-2 text-white/60">Anything over 80 worked hours is overtime.</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <input className="input max-w-xs" type="date" />
            <input className="input max-w-xs" type="date" />
            <button className="btn" onClick={() => window.print()}>Build Payroll PDF</button>
          </div>
          <table className="mt-6 w-full min-w-[700px]">
            <thead><tr className="text-left text-white/70"><th>Employee</th><th>Regular</th><th>OT</th><th>Holiday</th><th>Vacation</th><th>Sick</th><th>Admin/Training</th><th>Total</th></tr></thead>
            <tbody>{rows.map(r => (
              <tr key={r.employeeId} className="border-t border-white/10">
                <td className="py-3">{r.employeeName}</td><td>{r.regular}</td><td>{r.overtime}</td><td>{r.holiday}</td><td>{r.vacation}</td><td>{r.sick}</td><td>{r.adminTraining}</td><td>{r.grandTotal}</td>
              </tr>
            ))}</tbody>
          </table>
        </section>
      </main>
    </>
  );
}
