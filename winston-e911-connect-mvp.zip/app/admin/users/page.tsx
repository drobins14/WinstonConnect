'use client';

import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';
import { useState } from 'react';

export default function UsersPage() {
  const [users, setUsers] = useState([{ first:'Daniel', last:'Robins', role:'admin', shift:'Night', status:'active' }]);
  return (
    <>
      <Header /><Nav />
      <main className="mx-auto max-w-7xl px-4 pb-10">
        <section className="card">
          <div className="mb-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold">User Management</h1>
            <button className="btn" onClick={() => setUsers([...users, {first:'New', last:'User', role:'employee', shift:'', status:'active'}])}>Add User</button>
          </div>
          <div className="grid gap-3">
            {users.map((u, i) => (
              <div key={i} className="grid gap-2 rounded-xl bg-white/10 p-3 md:grid-cols-5">
                <input className="input" value={u.first} onChange={e => setUsers(users.map((x,idx)=>idx===i?{...x,first:e.target.value}:x))} />
                <input className="input" value={u.last} onChange={e => setUsers(users.map((x,idx)=>idx===i?{...x,last:e.target.value}:x))} />
                <input className="input" value={u.role} onChange={e => setUsers(users.map((x,idx)=>idx===i?{...x,role:e.target.value}:x))} />
                <input className="input" value={u.shift} onChange={e => setUsers(users.map((x,idx)=>idx===i?{...x,shift:e.target.value}:x))} />
                <button className="btn-secondary" onClick={() => setUsers(users.filter((_,idx)=>idx!==i))}>Deactivate</button>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}
