import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';
import Link from 'next/link';

export default function AdminPage() {
  return (
    <>
      <Header /><Nav />
      <main className="mx-auto grid max-w-7xl gap-4 px-4 pb-10 md:grid-cols-3">
        {[
          ['Users','/admin/users'],
          ['Payroll Builder','/admin/payroll'],
          ['Schedule Builder','/schedule'],
          ['Time Card Approvals','/time-card'],
          ['Notifications','/settings'],
          ['Reports','/admin/payroll'],
        ].map(([label, href]) => (
          <Link key={label} href={href} className="card hover:border-gold">
            <h2 className="text-xl font-bold">{label}</h2>
            <p className="mt-2 text-white/60">Open {label}</p>
          </Link>
        ))}
      </main>
    </>
  );
}
