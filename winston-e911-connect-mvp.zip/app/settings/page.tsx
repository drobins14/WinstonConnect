import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';

export default function SettingsPage() {
  return (
    <>
      <Header /><Nav />
      <main className="mx-auto max-w-3xl px-4 pb-10">
        <section className="card">
          <h1 className="text-2xl font-bold">Preferences</h1>
          <div className="mt-5 grid gap-4">
            <label className="flex items-center justify-between rounded-xl bg-white/10 p-4">In-app notifications <input type="checkbox" defaultChecked /></label>
            <label className="flex items-center justify-between rounded-xl bg-white/10 p-4">Email notifications <input type="checkbox" defaultChecked /></label>
            <label className="flex items-center justify-between rounded-xl bg-white/10 p-4">SMS notifications <input type="checkbox" /></label>
            <label>Accent color <input className="input mt-2 h-14" type="color" defaultValue="#d7a83d" /></label>
          </div>
        </section>
      </main>
    </>
  );
}
