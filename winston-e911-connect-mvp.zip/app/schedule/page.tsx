import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';

const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const rows = ['Open Day Shift','Open Night Shift','Daniel Robins','Jennifer','Trainees'];

export default function SchedulePage() {
  return (
    <>
      <Header /><Nav />
      <main className="mx-auto max-w-7xl px-4 pb-10">
        <section className="card">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h1 className="text-2xl font-bold">Master Schedule</h1>
            <div className="flex gap-2">
              <button className="btn-secondary">Day</button>
              <button className="btn-secondary">Week</button>
              <button className="btn-secondary">Month</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] border-separate border-spacing-2">
              <thead><tr><th className="text-left">Employee / Slot</th>{days.map(d => <th key={d}>{d}</th>)}</tr></thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r}>
                    <td className="rounded-xl bg-white/10 p-3 font-semibold">{r}</td>
                    {days.map((d, i) => (
                      <td key={d} className={`rounded-xl p-3 text-center ${r.includes('Open Day') ? 'bg-yellow-400 text-navy' : r.includes('Open Night') ? 'bg-cyan-400 text-navy' : r.includes('Trainees') ? 'bg-purple-400/30' : i % 2 ? 'bg-slate911' : 'bg-white/10'}`}>
                        {r.includes('Open') ? 'OPEN' : r.includes('Trainees') ? 'Training hrs' : i % 2 ? '0700-1900' : 'OFF'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </>
  );
}
