'use client';

import { Header } from '@/components/Header';
import { Nav } from '@/components/Nav';
import { useMemo, useState } from 'react';

const dates = Array.from({length: 14}, (_, i) => `Day ${i + 1}`);

export default function TimeCardPage() {
  const [rows, setRows] = useState(dates.map(date => ({ date, regular: 0, holiday: 0, vacation: 0, sick: 0, admin: 0 })));
  const worked = rows.reduce((s, r) => s + Number(r.regular || 0), 0);
  const regular = Math.min(worked, 80);
  const overtime = Math.max(worked - 80, 0);
  const total = rows.reduce((s, r) => s + Number(r.regular||0)+Number(r.holiday||0)+Number(r.vacation||0)+Number(r.sick||0)+Number(r.admin||0), 0);

  function update(i:number, key:string, value:string) {
    setRows(prev => prev.map((r, idx) => idx === i ? { ...r, [key]: Number(value) } : r));
  }

  return (
    <>
      <Header /><Nav />
      <main className="mx-auto max-w-7xl px-4 pb-10">
        <section className="card">
          <h1 className="mb-4 text-2xl font-bold">Time Card</h1>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[850px]">
              <thead><tr className="text-left text-sm text-white/70"><th>Date</th><th>Worked</th><th>Holiday</th><th>Vacation</th><th>Sick</th><th>Admin/Training</th></tr></thead>
              <tbody>{rows.map((r, i) => (
                <tr key={r.date} className="border-t border-white/10">
                  <td className="py-2">{r.date}</td>
                  {(['regular','holiday','vacation','sick','admin'] as const).map(k => (
                    <td key={k} className="py-2"><input className="input max-w-28" type="number" value={(r as any)[k]} onChange={e => update(i,k,e.target.value)} /></td>
                  ))}
                </tr>
              ))}</tbody>
            </table>
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-4">
            <div className="rounded-xl bg-white/10 p-4">Regular: <b>{regular}</b></div>
            <div className="rounded-xl bg-red911/20 p-4">Overtime: <b>{overtime}</b></div>
            <div className="rounded-xl bg-white/10 p-4">Grand Total: <b>{total}</b></div>
            <button className="btn">Submit Time Card</button>
          </div>
        </section>
      </main>
    </>
  );
}
