# Winston County E911 Connect

Communications Operations Management System

## MVP included
- Next.js app shell
- Dark mode public-safety UI
- Supabase database schema
- Role-based pages
- Temporary admin seed SQL
- User management screen
- Master schedule screen
- Manual time cards
- Payroll builder with >80 overtime rule
- Notification preferences model
- Trainee section model

## Setup
1. Create a new Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Run `supabase/seed-admin.sql`.
4. Copy `.env.example` to `.env.local`.
5. Fill in Supabase URL and anon key.
6. Install and run:

```bash
npm install
npm run dev
```

Temporary admin:
- username/email: admin@winston-e911.local
- password: Admin@911
